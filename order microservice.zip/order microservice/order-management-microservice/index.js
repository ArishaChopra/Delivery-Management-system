require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const { 
  orderManagementPromisePool, 
  userRegistrationPromisePool, 
  productCatalogPromisePool 
} = require('./db'); 
const authenticateJWT = require('./authMiddleware'); // Authentication middleware
const authorizeAdmin = require('./adminMiddleware');

const app = express();
const port = process.env.PORT || 6000; // Default port is 6000

// Middleware for parsing JSON bodies
app.use(bodyParser.json());

// Cart service URL (from environment variable)
const cartServiceUrl = process.env.CART_SERVICE_URL || 'http://localhost:5000/carts'; // Cart Service URL
const productServiceUrl = process.env.PRODUCT_SERVICE_URL || 'http://localhost:4000/products'; // Product Service URL
const userServiceUrl = process.env.USER_SERVICE_URL || 'http://localhost:3000'; // User Service URL
const shippingServiceUrl = process.env.SHIPPING_SERVICE_URL || 'http://localhost:3003'; // Shipping Service URL

// Function to validate if the user exists
const validateUser = async (user_id, token) => {
  try {
    console.log(`Validating user with ID: ${user_id}`);

    const response = await axios.get(`${userServiceUrl}/validate-user/${user_id}`, {
      headers: {
        'Authorization': `Bearer ${token}`, // Pass the JWT token to the User service
      },
    });

    if (String(response.data.user.id) === String(user_id)) {
      return true;
    } else {
      return false;
    }
  } catch (err) {
    console.error('Error validating user:', err.message);
    return false;
  }
};

// Admin route to view pending orders with details
app.get('/admin/orders/pending', authenticateJWT, authorizeAdmin, async (req, res) => {
  try {
    // Query to get all pending orders with user, shipping address, and products
    const query = `
      SELECT 
        o.id AS order_id, 
        o.order_status, 
        u.name AS user_name, 
        u.phone_number, 
        sa.address_line_1, 
        sa.address_line_2, 
        sa.city, 
        sa.state, 
        sa.country, 
        sa.postal_code, 
        sa.alternate_mobile_number, 
        oi.product_id, 
        p.name AS product_name, 
        oi.quantity, 
        oi.price
      FROM order_management.orders o
      JOIN user_registration.users u ON o.user_id = u.id
      JOIN order_management.shipping_addresses sa ON o.shipping_address_id = sa.id
      JOIN order_management.order_items oi ON o.id = oi.order_id
      JOIN product_catalog.products p ON oi.product_id = p.id
      WHERE o.order_status = 'pending'
    `;

    const [orders] = await orderManagementPromisePool.query(query); // Use the orderManagementPromisePool

    if (orders.length === 0) {
      return res.status(404).json({ message: 'No pending orders found' });
    }

    // Return the orders with all the necessary details
    res.status(200).json({ orders });
  } catch (err) {
    console.error('Error fetching pending orders:', err);
    res.status(500).json({ message: 'Error fetching pending orders' });
  }
});

// Place an Order (POST /orders)
app.post('/orders', authenticateJWT, async (req, res) => {
  const user_id = req.user.id; // Get user ID from the JWT token
  const { shipping_address_id } = req.body; // Assume the user selects the shipping address
  const token = req.headers.authorization.split(' ')[1]; // Extract the JWT token

  // Ensure the shipping address is provided
  if (!shipping_address_id) {
    return res.status(400).json({ message: 'Shipping address is required to place an order' });
  }

  try {
    // Step 1: Validate user existence using the validateUser function
    const isValidUser = await validateUser(user_id, token);

    if (!isValidUser) {
      return res.status(404).json({ message: 'User not found or invalid' });
    }

    // Step 2: Fetch the user's shipping address from the Shipping service
    const shippingResponse = await axios.get(`${shippingServiceUrl}/shipping-addresses`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    const selectedShippingAddress = shippingResponse.data.find(address => address.id === shipping_address_id);

    if (!selectedShippingAddress) {
      return res.status(404).json({ message: 'Shipping address not found' });
    }

    // Step 3: Fetch the user's cart to get the cart ID
    const cartResponse = await axios.get(`${cartServiceUrl}/${user_id}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    const cart = cartResponse.data;

    if (!cart || cart.length === 0) {
      return res.status(400).json({ message: 'No items in the cart to place an order' });
    }

    const cart_id = cart[0].cart_id;

    // Step 4: Create the order in the database with shipping address
    const orderQuery = 'INSERT INTO orders (user_id, shipping_address_id) VALUES (?, ?)';
    const [orderResults] = await orderManagementPromisePool.query(orderQuery, [user_id, shipping_address_id]);


    const order_id = orderResults.insertId;

    // Step 5: Insert order items into the order_items table
    const insertItemsQuery = 'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)';

    const orderItemPromises = cart.map((item) => {
      return orderManagementPromisePool.query(insertItemsQuery, [order_id, item.product_id, item.quantity, item.price]);
    });

    // Wait for all order items to be inserted
    await Promise.all(orderItemPromises);

    // Step 6: Empty the cart by calling the Cart service
    await axios.delete(`${cartServiceUrl}/${cart_id}/items`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    // Return success response
    res.status(201).json({ message: 'Order placed successfully and cart emptied', order_id });
  } catch (err) {
    console.error('Error placing order:', err);

    // Log the detailed response if it exists
    if (err.response) {
      console.error('Error response status:', err.response.status);
      console.error('Error response data:', err.response.data);
    }

    // Handle specific error codes if applicable
    if (err.response && err.response.status === 404) {
      return res.status(404).json({ message: 'User or Shipping address not found' });
    }

    if (err.response && err.response.status === 400) {
      return res.status(400).json({ message: 'No items in the cart to place an order' });
    }

    // Return a generic 500 error if something went wrong
    res.status(500).json({ message: 'Error placing order' });
  }
});

// Get orders by status for the user (GET /orders/status/:status)
app.get('/orders/status/:status', authenticateJWT, async (req, res) => {
  const user_id = req.user.id; // Get user ID from the JWT token
  const status = req.params.status; // Get status from URL parameter

  try {
    const query = 'SELECT * FROM orders WHERE user_id = ? AND order_status = ?';
    const [orders] = await pool.query(query, [user_id, status]);

    if (orders.length === 0) {
      return res.status(404).json({ message: 'No orders found with this status' });
    }

    res.status(200).json(orders);
  } catch (err) {
    console.error('Error fetching orders by status:', err);
    res.status(500).json({ message: 'Error fetching orders' });
  }
});

// View order history for the user (GET /orders/history)
app.get('/orders/history', authenticateJWT, async (req, res) => {
  const user_id = req.user.id; // Get user ID from the JWT token

  try {
    const query = 'SELECT * FROM orders WHERE user_id = ?';
    const [orders] = await pool.query(query, [user_id]);

    if (orders.length === 0) {
      return res.status(404).json({ message: 'No orders found for this user' });
    }

    res.status(200).json(orders);
  } catch (err) {
    console.error('Error fetching order history:', err);
    res.status(500).json({ message: 'Error fetching order history' });
  }
});

// Delete order by ID (DELETE /orders/:order_id)
app.delete('/orders/:order_id', authenticateJWT, async (req, res) => {
  const user_id = req.user.id; // Get user ID from the JWT token
  const { order_id } = req.params; // Get order_id from URL parameter

  try {
    const checkOrderQuery = 'SELECT * FROM orders WHERE id = ? AND user_id = ? AND order_status = "pending"';
    const [order] = await pool.query(checkOrderQuery, [order_id, user_id]);

    if (order.length === 0) {
      return res.status(404).json({ message: 'Order not found or cannot be deleted (only pending orders can be deleted)' });
    }

    const deleteOrderQuery = 'DELETE FROM orders WHERE id = ?';
    const deleteOrderItemsQuery = 'DELETE FROM order_items WHERE order_id = ?';

    await pool.query(deleteOrderItemsQuery, [order_id]);
    await pool.query(deleteOrderQuery, [order_id]);

    res.status(200).json({ message: 'Order deleted successfully' });
  } catch (err) {
    console.error('Error deleting order:', err);
    res.status(500).json({ message: 'Error deleting order' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Order management microservice is running on port ${port}`);
});
