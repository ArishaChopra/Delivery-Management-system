// adminMiddleware.js
const authenticateJWT = require('./authMiddleware'); // Import the general authentication middleware

// Middleware to check if the user is an admin
const authorizeAdmin = (req, res, next) => {
  // Call the general authentication middleware
  authenticateJWT(req, res, () => {
    // Now that the user is authenticated, check if the role is 'admin'
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied. Admins only.' });
    }
    
    next(); // Proceed to the next middleware or route handler if the user is an admin
  });
};

module.exports = authorizeAdmin;
