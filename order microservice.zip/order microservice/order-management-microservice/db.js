const mysql = require('mysql2');

// Create MySQL connection pools for each database
const orderManagementPool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'order_management', // Order Management DB
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

const userRegistrationPool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME_USER_REGISTRATION || 'user_registration', // User Registration DB
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

const productCatalogPool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME_PRODUCT || 'product_catalog', // Product Catalog DB
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Use the promise API for each pool (asynchronously)
const orderManagementPromisePool = orderManagementPool.promise();
const userRegistrationPromisePool = userRegistrationPool.promise();
const productCatalogPromisePool = productCatalogPool.promise();

// Export the pools so they can be used in other parts of the app
module.exports = {
  orderManagementPromisePool,
  userRegistrationPromisePool,
  productCatalogPromisePool
};
