const jwt = require('jsonwebtoken');

// Middleware to check if the user is authenticated and has an admin role
const isAdmin = async (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1];  // Get token from Authorization header

    if (!token) {
        return res.status(403).json({ message: 'No token provided, access forbidden' });
    }

    try {
        // Verify the JWT token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Extract the role from the decoded token
        const userRole = decoded.role;

        // Check if the user has an admin role
        if (userRole !== 'admin') {
            return res.status(403).json({ message: 'Access denied. Only admins can perform this action.' });
        }

        // Proceed to the next middleware/handler
        next();
    } catch (error) {
        console.error('[ERROR] Failed to authenticate:', error);
        return res.status(403).json({ message: 'Invalid or expired token, access forbidden' });
    }
};

module.exports = { isAdmin };
