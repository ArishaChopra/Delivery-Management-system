const express = require('express');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const pool = require('./db');
const axios = require('axios');  // Import axios to make HTTP requests
const { isAdmin } = require('./authMiddleware');
const swaggerUi = require('swagger-ui-express');
const swaggerJsdoc = require('swagger-jsdoc');

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(cors()); 
app.use(bodyParser.json());

// Swagger setup
const swaggerDefinition = {
  openapi: '3.0.0',
  info: {
    title: 'User Registration API',
    version: '1.0.0',
    description: 'API for user registration, updating verification status, and checking verification status',
  },
  servers: [
    {
      url: `http://localhost:${port}`,  // Update with your server's URL
    },
  ],
};

const options = {
  swaggerDefinition,
  apis: ['./app.js'],  // Path to your API route files (can also be a separate route file)
};

const swaggerSpec = swaggerJsdoc(options);

// Serve Swagger UI at /api-docs
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// Helper function to validate email format
const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
};

// Helper function to validate phone number (10 digits)
const validatePhoneNumber = (phone_number) => {
    const phoneRegex = /^[0-9]{10}$/;
    return phoneRegex.test(phone_number);
};

// Helper function to validate password (min 8 characters, one uppercase, one lowercase, one special character)
const validatePassword = (password) => {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return passwordRegex.test(password);
};

// Helper function to validate name (only alphabets allowed)
const validateName = (name) => {
    const nameRegex = /^[A-Za-z\s]+$/;  // Allows alphabets and spaces only
    return nameRegex.test(name);
};

// User registration route
/**
 * @swagger
 * /register:
 *   post:
 *     summary: Register a new user
 *     description: Register a user with name, email, phone number, and password.
 *     operationId: registerUser
 *     tags:
 *       - Users
 *     requestBody:
 *       description: User registration details
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: "John Doe"
 *               email:
 *                 type: string
 *                 example: "john.doe@example.com"
 *               phone_number:
 *                 type: string
 *                 example: "1234567890"
 *               password:
 *                 type: string
 *                 example: "P@ssw0rd123"
 *     responses:
 *       201:
 *         description: User registered successfully
 *       400:
 *         description: Invalid input or user already exists
 *       500:
 *         description: Internal server error
 */
app.post('/register', async (req, res) => {
    const { name, email, phone_number, password } = req.body;

    if (!name || !email || !phone_number || !password) {
        return res.status(400).json({ message: 'Please provide all required fields' });
    }

    // Validate input (basic validation)
    if (!validateName(name)) {
        return res.status(400).json({ message: 'Invalid name format' });
    }

    if (!validateEmail(email)) {
        return res.status(400).json({ message: 'Invalid email format' });
    }

    if (!validatePhoneNumber(phone_number)) {
        return res.status(400).json({ message: 'Phone number must be 10 digits' });
    }

    if (!validatePassword(password)) {
        return res.status(400).json({ message: 'Password must meet the requirements' });
    }

    try {
        const [existingUser] = await pool.execute('SELECT * FROM users WHERE email = ? OR phone_number = ?', [email, phone_number]);

        if (existingUser.length > 0) {
            return res.status(400).json({ message: 'Email or Phone number already in use' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const [result] = await pool.execute(
            'INSERT INTO users (name, email, phone_number, password, is_verified, role) VALUES (?, ?, ?, ?, ?, ?)',
            [name, email, phone_number, hashedPassword, false, 'user']
        );

        res.status(201).json({ message: 'User registered successfully. Please verify your email.' });
    } catch (err) {
        console.error("Error during user registration:", err);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

// Route to update user verification status
/**
 * @swagger
 * /update-verification:
 *   post:
 *     summary: Update user verification status
 *     description: Set the verification status for a user by email.
 *     operationId: updateVerification
 *     tags:
 *       - Users
 *     requestBody:
 *       description: Email and verification status to update
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               email:
 *                 type: string
 *                 example: "john.doe@example.com"
 *               is_verified:
 *                 type: boolean
 *                 example: true
 *     responses:
 *       200:
 *         description: Verification status updated successfully
 *       400:
 *         description: Invalid input
 *       404:
 *         description: User not found
 *       500:
 *         description: Internal server error
 */
app.post('/update-verification', async (req, res) => {
    const { email, is_verified } = req.body;

    if (!email || typeof is_verified === 'undefined') {
        return res.status(400).json({ message: 'Email and verification status are required' });
    }

    try {
        const [result] = await pool.execute(
            'UPDATE users SET is_verified = ? WHERE email = ?',
            [is_verified, email]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json({ message: 'User verification status updated successfully' });
    } catch (err) {
        console.error("Error during updating verification status:", err);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

// Route to check user verification status
/**
 * @swagger
 * /check-verification/{email}:
 *   get:
 *     summary: Check if a user is verified
 *     description: Check the verification status of a user by their email.
 *     operationId: checkVerification
 *     tags:
 *       - Users
 *     parameters:
 *       - name: email
 *         in: path
 *         description: Email of the user
 *         required: true
 *         schema:
 *           type: string
 *           example: "john.doe@example.com"
 *     responses:
 *       200:
 *         description: User verification status
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 is_verified:
 *                   type: boolean
 *                   example: false
 *       400:
 *         description: Invalid email format
 *       404:
 *         description: User not found
 *       500:
 *         description: Internal server error
 */
app.get('/check-verification/:email', async (req, res) => {
    const { email } = req.params;

    if (!validateEmail(email)) {
        return res.status(400).json({ message: 'Invalid email format' });
    }

    try {
        const [user] = await pool.execute('SELECT is_verified FROM users WHERE email = ?', [email]);

        if (user.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json({
            message: user[0].is_verified ? 'User is verified' : 'User is not verified',
            is_verified: user[0].is_verified,   
        });
    } catch (err) {
        console.error("Error during checking verification status:", err);
        return res.status(500).json({ message: 'Internal Server Error' });
    }
});

// Route to validate a user by user_id
/**
 * @swagger
 * /validate-user/{user_id}:
 *   get:
 *     summary: Validate if a user exists
 *     description: Check if a user exists by their user_id.
 *     operationId: validateUser
 *     tags:
 *       - Users
 *     parameters:
 *       - name: user_id
 *         in: path
 *         description: ID of the user to validate
 *         required: true
 *         schema:
 *           type: integer
 *           example: 123
 *     responses:
 *       200:
 *         description: User found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "User found"
 *                 user:
 *                   type: object
 *                   properties:
 *                     user_id:
 *                       type: integer
 *                       example: 123
 *                     name:
 *                       type: string
 *                       example: "John Doe"
 *                     email:
 *                       type: string
 *                       example: "john.doe@example.com"
 *       404:
 *         description: User not found
 *       500:
 *         description: Internal server error
 */
app.get('/validate-user/:user_id', async (req, res) => {
    const { user_id } = req.params;

    // Ensure user_id is valid (check if it's a valid number)
    if (isNaN(user_id) || user_id <= 0) {
        return res.status(400).json({ message: 'Invalid user ID' });
    }

    try {
        // Query the database to find the user with the given user_id (now using 'id' instead of 'user_id')
        const [user] = await pool.execute('SELECT id, name, email FROM users WHERE id = ?', [user_id]);

        if (user.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        // If the user is found, return the user information
        res.status(200).json({
            message: 'User found',
            user: user[0],  // Assuming the user exists and is returned as an array of one object
        });
    } catch (err) {
        console.error("Error during user validation:", err);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});


// Start the server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
