const crypto = require('crypto');
const pool = require('./db');  // Database connection
const axios = require('axios');  // For making HTTP requests

// Generate a random 6-digit OTP
const generateOtp = () => {
    return Math.floor(100000 + Math.random() * 900000).toString(); // Generates a 6-digit OTP
};

// Simulate OTP sending (using logs for now)
const sendOtp = (email, otp) => {
    console.log(`[LOG] Sending OTP to ${email}: ${otp}`);
    // In a real-world scenario, send the OTP to the user's email here (e.g., using an email service provider)
};

// Store OTP in the database with expiry time
const storeOtp = async (email, otp) => {
    const expiryTime = new Date(Date.now() + (parseInt(process.env.OTP_EXPIRY_TIME) * 1000)); // OTP expiry time in seconds
    try {
        const [result] = await pool.execute(
            'INSERT INTO otps (email, otp, expiry_time) VALUES (?, ?, ?)',
            [email, otp, expiryTime]
        );
        console.log(`[LOG] OTP stored in database for email: ${email}`);
    } catch (err) {
        console.error('[ERROR] Failed to store OTP in database:', err);
        throw new Error('Database error while storing OTP');
    }
};

// Update the user's verification status in the registration microservice
const updateUserVerificationStatus = async (email) => {
    try {
        const response = await axios.post('http://localhost:3000/update-verification', {
            email: email,
            is_verified: true
        });
        console.log(`User verification status updated: ${response.data.message}`);
        return true;  // Return true if the status was updated successfully
    } catch (error) {
        console.error('[ERROR] Error updating user verification status:', error.message);
        return false;  // Return false if there was an error
    }
};

// Verify the OTP entered by the user
const verifyOtp = async (email, otp) => {
    try {
        // Check if OTP exists for the given email
        const [rows] = await pool.execute(
            'SELECT * FROM otps WHERE email = ? AND otp = ? ORDER BY created_at DESC LIMIT 1',
            [email, otp]
        );

        if (rows.length === 0) {
            return { success: false, message: 'Invalid OTP' };
        }

        const otpRecord = rows[0];
        const currentTime = new Date();

        // Check if OTP has expired
        if (currentTime > new Date(otpRecord.expiry_time)) {
            return { success: false, message: 'OTP has expired' };
        }

        // OTP is valid, update user verification status
        const userVerified = await updateUserVerificationStatus(email);
        if (userVerified) {
            return { success: true, message: 'OTP verified successfully, user is now verified' };
        } else {
            return { success: false, message: 'Failed to update user verification status' };
        }
    } catch (err) {
        console.error('[ERROR] Failed to verify OTP:', err);
        return { success: false, message: 'Internal server error' };
    }
};

module.exports = { generateOtp, sendOtp, storeOtp, verifyOtp };
