const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const cors = require('cors');
const { generateOtp, sendOtp, storeOtp, verifyOtp } = require('./otp');

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;

// Middleware setup
app.use(cors());
app.use(bodyParser.json()); // JSON parsing middleware

// Route to request OTP
app.post('/request-otp', async (req, res) => {
    const { email } = req.body;

    // Validate email input
    if (!email) {
        return res.status(400).json({ message: 'Please provide an email address' });
    }

    try {
        // Generate OTP and store it
        const otp = generateOtp();  // Generate OTP
        sendOtp(email, otp);  // Simulating OTP sending (log for now, replace with actual service)
        await storeOtp(email, otp);  // Store OTP in the database

        // Respond to client that OTP has been sent
        res.status(200).json({ message: 'OTP sent successfully. Please check your email.' });
    } catch (error) {
        console.error('[ERROR] Failed to handle OTP request:', error);
        res.status(500).json({ message: 'Failed to send OTP' });
    }
});

// Route to verify OTP
app.post('/verify-otp', async (req, res) => {
    const { email, otp } = req.body;

    // Validate OTP and email input
    if (!email || !otp) {
        return res.status(400).json({ message: 'Please provide both email and OTP' });
    }

    try {
        // Verify the OTP
        const result = await verifyOtp(email, otp);  // Check if OTP is valid

        if (result.success) {
            // OTP is valid, return success message
            return res.status(200).json({ message: result.message });
        } else {
            // OTP verification failed
            return res.status(400).json({ message: result.message });
        }
    } catch (error) {
        console.error('[ERROR] OTP verification failed:', error);
        return res.status(500).json({ message: 'Internal server error' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`OTP Verification Service running on port ${port}`);
});
