// db.js
require('dotenv').config();
const mysql = require('mysql2');

// Create a MySQL connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'order_management',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Use the promise API for pool
const promisePool = pool.promise();  // Using the promise API from mysql2

module.exports = promisePool;
