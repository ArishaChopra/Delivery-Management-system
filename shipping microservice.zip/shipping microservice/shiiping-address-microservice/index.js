const express = require('express');
const bodyParser = require('body-parser');
const pool = require('./db'); // Import the database connection from db.js
const authenticateJWT = require('./authMiddleware'); // Import authentication middleware

const app = express();
const port = process.env.PORT || 3001;

// Middleware for parsing JSON bodies
app.use(bodyParser.json());

// Add Shipping Address (POST /shipping-addresses)
app.post('/shipping-addresses', authenticateJWT, async (req, res) => {
  const user_id = req.user.id; // Get the user ID from the JWT token
  const { address_line_1, address_line_2, alternate_mobile_number, city, state, country, postal_code } = req.body;

  if (!address_line_1 || !city || !country) {
    return res.status(400).json({ message: 'Address line 1, city, and country are required' });
  }

  try {
    const query = `
      INSERT INTO shipping_addresses 
      (user_id, address_line_1, address_line_2, alternate_mobile_number, city, state, country, postal_code) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const [results] = await pool.query(query, [user_id, address_line_1, address_line_2, alternate_mobile_number, city, state, country, postal_code]);
    res.status(201).json({ message: 'Shipping address added successfully', address_id: results.insertId });
  } catch (err) {
    console.error('Error adding shipping address:', err);
    res.status(500).json({ message: 'Error adding shipping address' });
  }
});

// Get Shipping Addresses (GET /shipping-addresses)
app.get('/shipping-addresses', authenticateJWT, async (req, res) => {
  const user_id = req.user.id; // Get the user ID from the JWT token

  try {
    const query = 'SELECT * FROM shipping_addresses WHERE user_id = ?';
    const [results] = await pool.query(query, [user_id]);

    if (results.length === 0) {
      return res.status(404).json({ message: 'No shipping addresses found for this user' });
    }

    res.status(200).json(results);
  } catch (err) {
    console.error('Error retrieving shipping addresses:', err);
    res.status(500).json({ message: 'Error retrieving shipping addresses' });
  }
});

// Update Shipping Address (PUT /shipping-addresses/:id)
app.put('/shipping-addresses/:id', authenticateJWT, async (req, res) => {
  const { id } = req.params;
  const { address_line_1, address_line_2, alternate_mobile_number, city, state, country, postal_code } = req.body;
  const user_id = req.user.id; // Get the user ID from the JWT token

  try {
    const query = `
      UPDATE shipping_addresses 
      SET address_line_1 = ?, address_line_2 = ?, alternate_mobile_number = ?, city = ?, state = ?, country = ?, postal_code = ?
      WHERE id = ? AND user_id = ?
    `;
    const [results] = await pool.query(query, [address_line_1, address_line_2, alternate_mobile_number, city, state, country, postal_code, id, user_id]);

    if (results.affectedRows === 0) {
      return res.status(404).json({ message: 'Shipping address not found or not owned by the user' });
    }

    res.status(200).json({ message: 'Shipping address updated successfully' });
  } catch (err) {
    console.error('Error updating shipping address:', err);
    res.status(500).json({ message: 'Error updating shipping address' });
  }
});

// Delete Shipping Address (DELETE /shipping-addresses/:id)
app.delete('/shipping-addresses/:id', authenticateJWT, async (req, res) => {
  const { id } = req.params;
  const user_id = req.user.id; // Get the user ID from the JWT token

  try {
    const query = 'DELETE FROM shipping_addresses WHERE id = ? AND user_id = ?';
    const [results] = await pool.query(query, [id, user_id]);

    if (results.affectedRows === 0) {
      return res.status(404).json({ message: 'Shipping address not found or not owned by the user' });
    }

    res.status(200).json({ message: 'Shipping address deleted successfully' });
  } catch (err) {
    console.error('Error deleting shipping address:', err);
    res.status(500).json({ message: 'Error deleting shipping address' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Shipping Address microservice is running on port ${port}`);
});
