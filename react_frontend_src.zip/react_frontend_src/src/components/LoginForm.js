import React, { useState } from 'react';

function LoginForm({ closeForm, onLoginSuccess }) { // Accept the onLoginSuccess prop
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [otpRequestSuccess, setOtpRequestSuccess] = useState(false);
  const [isOtpVerified, setIsOtpVerified] = useState(false);

  const handleEmailChange = (e) => setEmail(e.target.value);
  const handlePasswordChange = (e) => setPassword(e.target.value);
  const handleOtpChange = (e) => setOtp(e.target.value);

  const handleNext = async () => {
    if (step === 1 && email) {
      setIsLoading(true);
      setErrorMessage('');
      try {
        const response = await fetch(`http://localhost:3000/check-verification/${email}`);
        const data = await response.json();
        if (response.ok) {
          data.is_verified === 1 ? setStep(2) : setStep(3);
        } else {
          setErrorMessage('Failed to verify user. Please check your email or try again.');
        }
      } catch (error) {
        setErrorMessage('An error occurred while checking verification.');
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleSubmitOTPRequest = async () => {
    if (!email) {
      setErrorMessage('Please enter your email.');
      return;
    }
    setIsLoading(true);
    setErrorMessage('');
    try {
      const response = await fetch('http://localhost:3001/request-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      if (response.ok) {
        setOtpRequestSuccess(true);
      } else {
        const data = await response.json();
        setErrorMessage(data.message || 'Failed to request OTP. Please try again.');
      }
    } catch (error) {
      setErrorMessage('An error occurred while requesting OTP.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (!otp) {
      setErrorMessage('Please enter the OTP.');
      return;
    }
    setIsLoading(true);
    setErrorMessage('');
    try {
      const response = await fetch('http://localhost:3001/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otp }),
      });
      if (response.ok) {
        setIsOtpVerified(true);
        setStep(2);
      } else {
        const data = await response.json();
        setErrorMessage(data.message || 'Failed to verify OTP. Please try again.');
      }
    } catch (error) {
      setErrorMessage('An error occurred while verifying OTP.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage('');
    try {
      const response = await fetch('http://localhost:3002/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (response.ok) {
        // Call the onLoginSuccess prop to toggle ProductPage visibility
        onLoginSuccess();  // Show the ProductPage
        closeForm();        // Close the LoginForm
      } else {
        const data = await response.json();
        setErrorMessage(data.message || 'Failed to log in. Please check your credentials.');
      }
    } catch (error) {
      setErrorMessage('An error occurred while logging in.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="register-form-container">
      <div className="register-form">
        <button className="close-btn" onClick={closeForm}>X</button>
        <h2>Login</h2>
        {errorMessage && <div className="error-message">{errorMessage}</div>}
        {step === 1 && (
          <form>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input type="email" id="email" value={email} onChange={handleEmailChange} required />
            </div>
            <button
              type="button"
              className="submit-btn"
              onClick={handleNext}
              disabled={!email || isLoading}
            >
              {isLoading ? 'Checking...' : 'Next'}
            </button>
          </form>
        )}
        {step === 2 && (
          <form onSubmit={handleSubmitLogin}>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input type="password" id="password" value={password} onChange={handlePasswordChange} required />
            </div>
            <button
              type="submit"
              className="submit-btn"
              disabled={isLoading}
            >
              {isLoading ? 'Logging in...' : 'Login'}
            </button>
          </form>
        )}
        {step === 3 && !isOtpVerified && (
          <div>
            {!otpRequestSuccess && (
              <div>
                <h3>Your account is not verified.</h3>
                <p>Please request an OTP to verify your account.</p>
              </div>
            )}
            {!otpRequestSuccess && (
              <button
                type="button"
                className="submit-btn"
                onClick={handleSubmitOTPRequest}
                disabled={isLoading}
              >
                {isLoading ? 'Requesting OTP...' : 'Request OTP'}
              </button>
            )}
            {otpRequestSuccess && (
              <div>
                <div className="success-message">OTP has been sent to your email!</div>
                <div className="form-group">
                  <label htmlFor="otp">Enter OTP</label>
                  <input type="text" id="otp" value={otp} onChange={handleOtpChange} required />
                </div>
                <button
                  type="button"
                  className="submit-btn"
                  onClick={handleVerifyOtp}
                  disabled={!otp || isLoading}
                >
                  {isLoading ? 'Verifying OTP...' : 'Verify OTP'}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default LoginForm;
