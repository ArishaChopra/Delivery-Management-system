import React from 'react';
import './ProductPage.css'; // Ensure you import your updated CSS

function ProductPage({ onBackToLanding }) {
  return (
    <div className="product-page">
      <div className="product-container">
        <div className="product-card">
          <img
            src="https://via.placeholder.com/400" // Replace with actual product image URL
            alt="Product"
            className="product-image"
          />
          <div className="product-details">
            <h2 className="product-title">Awesome Product</h2>
            <p className="product-description">
              This is a fantastic product that you will love! It's packed with amazing features and will make your life so much easier.
            </p>
            <div className="product-price">$199.99</div>
            <button className="back-btn" onClick={onBackToLanding}>
              Back to Landing Page
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductPage;
