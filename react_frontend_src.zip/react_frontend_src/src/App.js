import React, { useState } from 'react';
import './App.css';
import RegisterForm from './components/RegisterForm';
import LoginForm from './components/LoginForm';
import ProductPage from './components/ProductPage'; // Import ProductPage component

function App() {
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isProductPageVisible, setIsProductPageVisible] = useState(false); // State to toggle ProductPage visibility

  const toggleRegisterForm = () => setIsRegisterOpen(!isRegisterOpen);
  const toggleLoginForm = () => setIsLoginOpen(!isLoginOpen);

  const closeLoginForm = () => setIsLoginOpen(false); // Function to close the LoginForm

  const toggleProductPage = () => {
    setIsProductPageVisible(true); // Show product page on login success
  };

  const handleBackToLanding = () => {
    setIsProductPageVisible(false); // Hide product page and return to landing page
  };

  return (
    <div className="App">
      {/* Conditionally render header and landing page elements */}
      {!isProductPageVisible && (
        <header className="App-header">
          <h1 className="logo">My Website</h1>
          <div className="auth-buttons">
            <button className="auth-btn" onClick={toggleRegisterForm}>
              Register
            </button>
            <button className="auth-btn" onClick={toggleLoginForm}>
              Login
            </button>
          </div>
        </header>
      )}

      {/* Render Product Page if isProductPageVisible is true */}
      {isProductPageVisible && <ProductPage onBackToLanding={handleBackToLanding} />}

      {/* Render Register Form if isRegisterOpen is true */}
      {isRegisterOpen && <RegisterForm closeForm={() => setIsRegisterOpen(false)} />}

      {/* Render Login Form if isLoginOpen is true */}
      {isLoginOpen && <LoginForm closeForm={closeLoginForm} onLoginSuccess={toggleProductPage} />}
    </div>
  );
}

export default App;
