require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const pool = require('./db'); // Import the database connection from db.js
const axios = require('axios'); // Import axios to make HTTP requests to the product and user microservices
const authenticateJWT = require('./authMiddleware'); // Import the auth middleware

const app = express();
const port = process.env.PORT || 3000;

// Middleware for parsing JSON bodies
app.use(bodyParser.json());

// Define the base URLs for product and user microservices
const productServiceUrl = process.env.PRODUCT_SERVICE_URL || 'http://localhost:4000/products'; // URL of your product service
const userServiceUrl = process.env.USER_SERVICE_URL || 'http://localhost:3000/validate-user'; // URL of your user service

// Function to validate if the user exists
const validateUser = async (user_id) => {
  try {
    console.log(`Validating user with ID: ${user_id}`);  // Log the user_id to see which user is being validated

    const response = await axios.get(`${userServiceUrl}/${user_id}`);
    
    console.log('User service response:', response.data);  // Log the full response from the user service

    // Ensure user_id is compared as a string
    if (String(response.data.user.id) === String(user_id)) {
      console.log(`User with ID ${user_id} found.`);
      return true;
    } else {
      console.log(`User with ID ${user_id} not found in the response.`);
      return false;
    }
  } catch (err) {
    console.error('Error validating user:', err.message);  // Log the error message
    console.error('Error details:', err);  // Log the full error object to see more details
    return false;  // Return false if there’s an error in calling the user microservice
  }
};



// Create Cart (POST /carts)
app.post('/carts', authenticateJWT, async (req, res) => {
  const user_id = req.user.id; // Get the authenticated user's ID from JWT token

  // Validate the user first
  const isValidUser = await validateUser(user_id);
  if (!isValidUser) {
    return res.status(404).json({ message: 'User not found' });
  }

  // Check if the user already has an existing cart
  const checkCartQuery = 'SELECT id FROM carts WHERE user_id = ? LIMIT 1';
  pool.query(checkCartQuery, [user_id], (err, results) => {
    if (err) {
      console.error('Error checking existing cart:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }

    if (results.length > 0) {
      // User already has a cart, return the existing cart
      return res.status(200).json({ message: 'Cart already exists', cart_id: results[0].id });
    }

    // If no cart exists, create a new cart
    const createCartQuery = 'INSERT INTO carts (user_id) VALUES (?)';
    pool.query(createCartQuery, [user_id], (err, results) => {
      if (err) {
        console.error('Error creating cart:', err);
        return res.status(500).json({ message: 'Internal server error' });
      }
      res.status(201).json({ message: 'Cart created successfully', cart_id: results.insertId });
    });
  });
});

// Add Item to Cart (POST /carts/:cart_id/items)
app.post('/carts/:cart_id/items', authenticateJWT, async (req, res) => {
  const { cart_id } = req.params;
  const { product_id, quantity, price } = req.body;
  const user_id = req.user.id; // Get the authenticated user's ID from JWT token

  if (!product_id || !quantity || !price) {
    return res.status(400).json({ message: 'Product ID, quantity, and price are required' });
  }

  // Validate the user before proceeding
  const isValidUser = await validateUser(user_id);
  if (!isValidUser) {
    return res.status(404).json({ message: 'User not found' });
  }

  try {
    // Call the Product Microservice to fetch product details
    const productResponse = await axios.get(`${productServiceUrl}/${product_id}`);
    const product = productResponse.data;

    // If the product doesn't exist, return an error
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Add item to cart
    const query = 'INSERT INTO cart_items (cart_id, product_id, quantity, price) VALUES (?, ?, ?, ?)';
    pool.query(query, [cart_id, product_id, quantity, price], (err, results) => {
      if (err) {
        console.error('Error adding item to cart:', err);
        return res.status(500).json({ message: 'Internal server error' });
      }
      res.status(201).json({ message: 'Item added to cart successfully', item_id: results.insertId });
    });

  } catch (err) {
    console.error('Error fetching product data:', err);
    res.status(500).json({ message: 'Error fetching product data' });
  }
});

// Get Cart Items (GET /carts/:user_id)
app.get('/carts/:user_id', authenticateJWT, async (req, res) => {
  const { user_id } = req.params;

  // Validate the user before proceeding
  const isValidUser = await validateUser(user_id);
  if (!isValidUser) {
    return res.status(404).json({ message: 'User not found' });
  }

  // Get the user's cart and its items
  const query = `
    SELECT c.id as cart_id, ci.id as item_id, ci.product_id, ci.quantity, ci.price 
    FROM carts c
    LEFT JOIN cart_items ci ON c.id = ci.cart_id
    WHERE c.user_id = ?
  `;
  pool.query(query, [user_id], async (err, results) => {
    if (err) {
      console.error('Error retrieving cart items:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }
    if (results.length === 0) {
      return res.status(404).json({ message: 'No cart found for this user' });
    }

    try {
      // Fetch product details for each cart item
      const cartItems = await Promise.all(results.map(async (item) => {
        const productResponse = await axios.get(`${productServiceUrl}/${item.product_id}`);
        item.product = productResponse.data; // Attach product data to the cart item
        return item;
      }));

      res.status(200).json(cartItems);
    } catch (err) {
      console.error('Error fetching product data for cart items:', err);
      res.status(500).json({ message: 'Error fetching product data for cart items' });
    }
  });
});

// Update Cart Item Quantity (PUT /carts/:cart_id/items/:item_id)
app.put('/carts/:cart_id/items/:item_id', authenticateJWT, async (req, res) => {
  const { cart_id, item_id } = req.params;
  const { quantity } = req.body;
  const user_id = req.user.id; // Get the authenticated user's ID from JWT token

  if (!quantity || quantity <= 0) {
    return res.status(400).json({ message: 'Valid quantity is required' });
  }

  // Validate the user before proceeding
  const isValidUser = await validateUser(user_id);
  if (!isValidUser) {
    return res.status(404).json({ message: 'User not found' });
  }

  // Update the quantity of the item in the cart
  const query = 'UPDATE cart_items SET quantity = ? WHERE cart_id = ? AND id = ?';
  pool.query(query, [quantity, cart_id, item_id], (err, results) => {
    if (err) {
      console.error('Error updating cart item:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }
    res.status(200).json({ message: 'Cart item updated successfully' });
  });
});

// Remove Item from Cart (DELETE /carts/:cart_id/items/:item_id)
app.delete('/carts/:cart_id/items/:item_id', authenticateJWT, async (req, res) => {
  const { cart_id, item_id } = req.params;
  const user_id = req.user.id; // Get the authenticated user's ID from JWT token

  // Validate the user before proceeding
  const isValidUser = await validateUser(user_id);
  if (!isValidUser) {
    return res.status(404).json({ message: 'User not found' });
  }

  // Remove item from the cart
  const query = 'DELETE FROM cart_items WHERE cart_id = ? AND id = ?';
  pool.query(query, [cart_id, item_id], (err, results) => {
    if (err) {
      console.error('Error deleting cart item:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }
    if (results.affectedRows === 0) {
      return res.status(404).json({ message: 'Item not found in this cart' });
    }
    res.status(200).json({ message: 'Item removed from cart successfully' });
  });
});

// Delete All Items from Cart (DELETE /carts/:cart_id/items)
app.delete('/carts/:cart_id/items', authenticateJWT, async (req, res) => {
  const { cart_id } = req.params;
  const user_id = req.user.id;  // Get the authenticated user's ID from JWT token

  // Validate the user before proceeding
  const isValidUser = await validateUser(user_id);
  if (!isValidUser) {
    return res.status(404).json({ message: 'User not found' });
  }

  // Check if the user owns the cart
  const checkCartQuery = 'SELECT user_id FROM carts WHERE id = ? LIMIT 1';
  pool.query(checkCartQuery, [cart_id], (err, results) => {
    if (err) {
      console.error('Error checking cart owner:', err);
      return res.status(500).json({ message: 'Internal server error' });
    }

    if (results.length === 0 || results[0].user_id !== user_id) {
      return res.status(403).json({ message: 'You do not have permission to delete items from this cart' });
    }

    // Delete all items from the cart
    const deleteItemsQuery = 'DELETE FROM cart_items WHERE cart_id = ?';
    pool.query(deleteItemsQuery, [cart_id], (err, deleteResults) => {
      if (err) {
        console.error('Error deleting cart items:', err);
        return res.status(500).json({ message: 'Internal server error' });
      }

      // If no items were deleted, return a message
      if (deleteResults.affectedRows === 0) {
        return res.status(404).json({ message: 'No items found in the cart' });
      }

      res.status(200).json({ message: 'All items deleted from the cart successfully' });
    });
  });
});


// Start the server
app.listen(port, () => {
  console.log(`Cart management microservice is running on port ${port}`);
});
