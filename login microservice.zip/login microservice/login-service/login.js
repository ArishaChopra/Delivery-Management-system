// login.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const axios = require('axios');
const pool = require('./db');  // Database connection

// Function to check if the user is verified
const isUserVerified = async (email) => {
    try {
        // Call the external user registration service to check the verification status
        const response = await axios.get(`http://localhost:3000/check-verification/${email}`);
        
        // Return true or false based on the is_verified status
        return response.data.is_verified === 1;  // Assuming 1 means verified
    } catch (error) {
        console.error('[ERROR] Failed to check user verification:', error);
        return false;  // In case of failure, return false
    }
};

// Function to check user credentials (email and password)
const checkUserCredentials = async (email, password) => {
    try {
        // Check if the user exists in the local database
        const [user] = await pool.execute('SELECT * FROM users WHERE email = ?', [email]);

        if (user.length === 0) {
            return { success: false, message: 'User not found' };
        }

        // Compare the provided password with the hashed password in the database
        const isPasswordValid = await bcrypt.compare(password, user[0].password);

        if (!isPasswordValid) {
            return { success: false, message: 'Invalid password' };
        }

        return { success: true, user: user[0] };
    } catch (err) {
        console.error('[ERROR] Failed to check user credentials:', err);
        return { success: false, message: 'Internal server error' };
    }
};

// Function to generate JWT token after successful login
const generateJwtToken = (user) => {
    const payload = {
        id: user.id,
        email: user.email,
        role: user.role  // Add the role here if needed
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

    return token;
};

module.exports = { checkUserCredentials, isUserVerified, generateJwtToken };
