const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const dotenv = require('dotenv');
const { checkUserCredentials, isUserVerified, generateJwtToken } = require('./login');

dotenv.config();

const app = express();
const port = process.env.PORT || 3002;

app.use(cors());

// Middleware
app.use(bodyParser.json());

// Route to login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    // Check if both email and password are provided
    if (!email || !password) {
        return res.status(400).json({ message: 'Email and password are required' });
    }

    try {
        // Step 1: Check if the user credentials (email and password) are valid
        const credentialsResult = await checkUserCredentials(email, password);

        if (!credentialsResult.success) {
            return res.status(400).json({ message: credentialsResult.message });
        }

        const user = credentialsResult.user;

        // Step 2: Check if the user is verified (only if credentials are valid)
        const isVerified = await isUserVerified(email);

        // If is_verified is undefined, send a server error message
        if (isVerified === undefined) {
            return res.status(500).json({ message: 'Error checking user verification status.' });
        }

        if (isVerified === false) {
            // User is not verified
            return res.status(403).json({
                message: 'User is not verified. Please verify your email first.',
                is_verified: false, // Explicitly return the unverified status
            });
        }

        // Step 3: Generate JWT token for the logged-in user
        const token = generateJwtToken(user);

        // Step 4: Return the login response with the token and is_verified status
        return res.status(200).json({
            message: 'Login successful',
            token: token,
            is_verified: true,  // Explicitly indicate the user is verified
        });

    } catch (error) {
        console.error('Error during login process:', error);
        return res.status(500).json({ message: 'An error occurred during login. Please try again.' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Login Microservice running on port ${port}`);
});
