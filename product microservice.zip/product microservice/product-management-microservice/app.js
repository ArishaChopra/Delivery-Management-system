const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const pool = require('./db'); // Database connection
const { isAdmin } = require('./authMiddleware');  // Import the isAdmin middleware

dotenv.config();

const app = express();
const port = process.env.PORT || 4000;

// Middleware to parse JSON
app.use(bodyParser.json());

// Route to add a new product - **Only Admin can access**
app.post('/products', isAdmin, async (req, res) => {
    const { name, description, price, batch, manufacturing_date } = req.body;

    // Validate if all fields are present
    if (!name || !description || !price || !batch || !manufacturing_date) {
        return res.status(400).json({ message: 'All product fields are required' });
    }

    try {
        // Insert new product into the database
        const [result] = await pool.execute(
            'INSERT INTO products (name, description, price, batch, manufacturing_date) VALUES (?, ?, ?, ?, ?)',
            [name, description, price, batch, manufacturing_date]
        );

        res.status(201).json({ message: 'Product added successfully', productId: result.insertId });
    } catch (err) {
        console.error('[ERROR] Failed to add product:', err);
        res.status(500).json({ message: 'Failed to add product' });
    }
});

// Route to get all products (Browse products)
app.get('/products', async (req, res) => {
    const { search, sortBy, sortOrder = 'asc', page = 1, limit = 10 } = req.query; // Query params

        // Calculate the offset for pagination
        const offset = (page - 1) * limit;

    // Initialize the query string
    let query = 'SELECT * FROM products';
    let queryParams = [];

    // Add filtering by name (if 'search' query param is provided)
    if (search) {
        query += ' WHERE name LIKE ?';
        queryParams.push(`%${search}%`);
    }

    // Add sorting by price, manufacturing_date, or name (if 'sortBy' query param is provided)
    if (sortBy && ['price', 'manufacturing_date', 'name'].includes(sortBy)) {
        query += ` ORDER BY ${sortBy} ${sortOrder.toUpperCase()}`;
    } else {
        // Default sort is by name
        query += ' ORDER BY name';
    }

    // Add pagination (LIMIT and OFFSET)
    query += ' LIMIT ? OFFSET ?';
    queryParams.push(Number(limit), Number(offset));

    try {
        const [products] = await pool.execute(query, queryParams);
        res.status(200).json({ products });
    } catch (err) {
        console.error('[ERROR] Failed to fetch products:', err);
        res.status(500).json({ message: 'Failed to fetch products' });
    }

    
});


// Route to get a product by ID
app.get('/products/:id', async (req, res) => {
    const { id } = req.params;

    try {
        const [product] = await pool.execute('SELECT * FROM products WHERE id = ?', [id]);

        if (product.length === 0) {
            return res.status(404).json({ message: 'Product not found' });
        }

        res.status(200).json({ product: product[0] });
    } catch (err) {
        console.error('[ERROR] Failed to fetch product:', err);
        res.status(500).json({ message: 'Failed to fetch product' });
    }
});

// Route to update a product by ID - **Only Admin can access**
app.put('/products/:id', isAdmin, async (req, res) => {
    const { id } = req.params;
    const { name, description, price, batch, manufacturing_date } = req.body;

    // Validate if all fields are present
    if (!name || !description || !price || !batch || !manufacturing_date) {
        return res.status(400).json({ message: 'All fields are required to update the product' });
    }

    try {
        const [result] = await pool.execute(
            'UPDATE products SET name = ?, description = ?, price = ?, batch = ?, manufacturing_date = ? WHERE id = ?',
            [name, description, price, batch, manufacturing_date, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Product not found' });
        }

        res.status(200).json({ message: 'Product updated successfully' });
    } catch (err) {
        console.error('[ERROR] Failed to update product:', err);
        res.status(500).json({ message: 'Failed to update product' });
    }
});

// Route to delete a product by ID - **Only Admin can access**
app.delete('/products/:id', isAdmin, async (req, res) => {
    const { id } = req.params;

    try {
        // Attempt to delete the product from the database
        const [result] = await pool.execute('DELETE FROM products WHERE id = ?', [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Product not found' });
        }

        // Respond with success
        res.status(200).json({ message: 'Product deleted successfully' });
    } catch (err) {
        console.error('[ERROR] Failed to delete product:', err);
        res.status(500).json({ message: 'Failed to delete product' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Product Management Microservice running on port ${port}`);
});
