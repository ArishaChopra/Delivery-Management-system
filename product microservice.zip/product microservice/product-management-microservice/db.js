const mysql = require('mysql2');
require('dotenv').config();  // Load environment variables

// Create a MySQL connection pool using the environment variables
const pool = mysql.createPool({
    host: process.env.DB_HOST,         // e.g., localhost
    user: process.env.DB_USER,         // Database username
    password: process.env.DB_PASSWORD, // Database password
    database: process.env.DB_NAME      // Database name
});

// Create a promise-based wrapper for the pool (used in async/await)
const promisePool = pool.promise();

// Test the connection immediately
/*
pool.getConnection((err, connection) => {
    if (err) {
        console.error('Error connecting to MySQL:', err.stack);
    } else {
        console.log('Connected to MySQL as id ' + connection.threadId);
        connection.release();  // Don't forget to release the connection after testing
    }
});*/

// Export the promisePool to be used in other parts of your app
module.exports = promisePool;
